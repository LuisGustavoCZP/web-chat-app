export interface Emoji 
{
    "emoji": string,
    "description": string,
    "version": string,
    "keywords":string[],
    "category":string,
    "group":string,
    "subgroup":string
}
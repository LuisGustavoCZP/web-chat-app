import { Emoji } from "./emoji";

export type Emojis = { [key : string] : Emoji[] } 
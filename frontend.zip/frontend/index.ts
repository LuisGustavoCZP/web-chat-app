export { router } from "./routes";
export * as views from "./views";